# kraken_soc_func Behavioral Simulation Guide

## Overview

This guide explains how to run behavioral simulation for the kraken_soc_func design on Arty A7-100T.

## Files Modified/Created

### 1. **RTL Changes**
- **File:** `rtl/kraken_soc_func.sv`
- **Change:** Removed unused `test_en_i` port
- **Reason:** Signal was declared but never used, cleaned up for synthesis

### 2. **Testbench Created**
- **File:** `sim/kraken_soc_func_tb.sv` (NEW)
- **Features:**
  - 100 MHz clock generation (10ns period)
  - Active-low reset with 5-cycle assertion
  - Signal monitoring with cycle counters
  - Activity tracking for:
    - PULP cluster address/request signals
    - Memory interface signals
    - CUTIE accelerator signals
  - VCD waveform dump for GTKWave/Vivado viewer
  - Console output with signal statistics

### 3. **Simulation Script Created**
- **File:** `run_sim.tcl` (NEW)
- **Purpose:** Automated simulation launch with Vivado
- **Duration:** 10 microseconds
- **Output:** `kraken_soc_func.vcd` waveform file

### 4. **Constraints Updated**
- **File:** `constraints/kraken_soc_func_synth.xdc`
- **Change:** test_en_i already removed (no constraints present)
- **Status:** ✅ No changes needed

## Running Behavioral Simulation

### Method 1: Using Vivado GUI (Recommended for First-Time)

```bash
cd C:\Users\kiran\fpga_project\mini_kraken
vivado mini_kraken.xpr
```

Then in Vivado:
1. **Project Manager** → Click on **Simulation** (left sidebar)
2. **Simulation Sources** → Right-click → **Add Sources**
3. Select `sim/kraken_soc_func_tb.sv`
4. **Set as Top** for simulation
5. Click **Run Simulation** (Play button)
6. View waveforms in wave window

### Method 2: Batch Mode (Command Line)

```bash
cd C:\Users\kiran\fpga_project\mini_kraken
vivado -mode batch -source run_sim.tcl
```

This will:
- Auto-add testbench to simulation fileset
- Compile design
- Run 10µs simulation
- Generate `kraken_soc_func.vcd`

### Method 3: Using xsim Directly (Advanced)

```bash
cd C:\Users\kiran\fpga_project\mini_kraken\sim

# Compile RTL and testbench
xvlog -sv ../rtl/kraken_soc_func.sv kraken_soc_func_tb.sv

# Elaborate
xelab -top kraken_soc_func_tb work.kraken_soc_func_tb

# Simulate
xsim work.kraken_soc_func_tb -gui
```

## Expected Simulation Behavior

### Reset Phase (t=0 to t=50ns)

```
Period  clk_i  rst_ni  rst_sync_ff_q  rst_n_q  core_0_req_o  mem_valid_o
───────────────────────────────────────────────────────────────────────
t=0ns    0      0         X            X          X             X
t=5ns    1      0         X            X          X             X
t=10ns   0      0         X            X          X             X
...
t=50ns   1      1         1            1        (active)      (active)
```

### Expected Signal Activity (After Reset Release)

1. **clk_i** → Oscillating 0↔1 at 100 MHz ✅
2. **rst_ni** → HIGH and stable ✅
3. **core_0_addr_o** → Shows instruction addresses (not stuck at 0 or ZZZZ) ✅
4. **core_0_req_o** → Should pulse during PULP execution ✅
5. **mem_valid_o** → Should show activity ✅
6. **mem_data_o** → Should change based on SRAM reads ✅
7. **cutie_busy_o** → Should pulse periodically (~every 16-256 cycles) ✅
8. **cutie_evt_o** → Should show occasional event signals ✅

## Console Output Example

After simulation completes (~10µs), you'll see:

```
═══════════════════════════════════════════════════════════════
kraken_soc_func Behavioral Simulation Started
───────────────────────────────────────────────────────────────
Clock Period: 10ns (100 MHz)
Reset Cycles: 5
═══════════════════════════════════════════════════════════════
@2000ns | Cycle: 200 | addr_o=00000004 | data_o=xxxxxxxx | req_o=1 | mem_valid=1 | busy=0 | evt=00
@3000ns | Cycle: 300 | addr_o=00000008 | data_o=xxxxxxxx | req_o=1 | mem_valid=1 | busy=0 | evt=00
...
═══════════════════════════════════════════════════════════════
Simulation Complete
───────────────────────────────────────────────────────────────
Total cycles after reset: 1000000
Signal Activity Summary:
  ✓ PULP Address Activity: YES
  ✓ PULP Request Activity: YES
  ✓ Memory Activity:       YES
  ✓ CUTIE Activity:        YES
═══════════════════════════════════════════════════════════════
```

## Viewing Waveforms

### Using Vivado Wave Viewer (GUI)

1. After simulation completes, waveforms automatically display
2. Zoom/Pan using mouse wheel and scrollbars
3. Add signals from **Objects** panel (left sidebar)
4. Search signals by name using **Find** (Ctrl+F)

### Using GTKWave (External Viewer)

```bash
gtkwave kraken_soc_func.vcd &
```

Then:
1. File → Open → Select `kraken_soc_func.vcd`
2. Drag signals from left panel to viewing area
3. Zoom to areas of interest

### Using VCD2Excel (Generate Report)

```bash
python3 vcd_to_csv.py kraken_soc_func.vcd > sim_report.csv
```

(Optional tool for further analysis)

## Common Simulation Issues

### Issue 1: Signals Show 'X' (Undefined)

**Symptom:** All outputs show XXXX or don't change

**Root Cause:** 
- Reset not properly released
- Logic not reaching valid state

**Fix:**
- Increase `RESET_CYCLES` in testbench if needed
- Check that `rst_ni` goes HIGH after `#(CLK_PERIOD * RESET_CYCLES)`

### Issue 2: Clock Doesn't Oscillate

**Symptom:** `clk_i` stuck at 0 or 1

**Root Cause:**
- Clock generation not executing

**Fix:**
- Verify `initial` block with `forever #5ns clk_i = ~clk_i;` is present
- Check testbench syntax

### Issue 3: No Signal Activity

**Symptom:** All outputs remain at 0 or Z after reset

**Root Cause:**
- PULP cluster or CUTIE not instantiated correctly
- Memory not connected

**Fix:**
- Check RTL instantiations
- Verify IP cores are available in project
- Run elaboration to check for missing modules

### Issue 4: Simulation Takes Too Long

**Symptom:** Simulation runs >1 minute

**Root Cause:**
- `SIM_TIME = 10us` is large
- Computer performance

**Fix:**
- Reduce `SIM_TIME` in testbench (e.g., `1us`)
- Use headless mode: `vivado -mode batch -source run_sim.tcl`

## Advancing Beyond Behavioral

### Functional Verification

After behavioral simulation passes:

1. **Add RTL-level assertions** in testbench
2. **Verify instruction sequences** by loading firmware
3. **Test interrupt handling** via CUTIE events
4. **Benchmark performance** (cycles per instruction)

### Post-Synthesis Simulation

```bash
vivado -mode batch -source run_sim_postsyn.tcl
```

This runs timing-accurate simulation after optimization.

### Hardware Testing (Arty A7-100T)

```bash
vivado -mode batch -source run_synth_impl.tcl
xc37a100t_program.py kraken_soc_func.bit
# Verify on hardware with JTAG debugger
```

## Troubleshooting Checklist

- [ ] Testbench file exists at `sim/kraken_soc_func_tb.sv`
- [ ] RTL file updated (test_en_i removed)
- [ ] Project recognizes `kraken_soc_func` as top module
- [ ] All IP cores (PULP, CUTIE, SRAM) resolved in project
- [ ] Clock period is 10ns (100 MHz)
- [ ] Reset assertion lasts ≥5 cycles
- [ ] No elaboration errors in Vivado console
- [ ] Simulation runs for at least 1000 cycles
- [ ] Waveform shows oscillating clock
- [ ] Waveform shows reset pulse then HIGH

## Summary

✅ **Behavioral simulation ready to use**

**Next Steps:**
1. Run simulation using any of the 3 methods above
2. Verify expected signal activity matches behavior
3. Once passing, proceed to synthesis/implementation
4. Finally, program Arty A7-100T and validate on hardware

**Files to keep for reference:**
- `sim/kraken_soc_func_tb.sv` - Main testbench
- `run_sim.tcl` - Automation script
- `kraken_soc_func.vcd` - Generated waveforms (after first run)


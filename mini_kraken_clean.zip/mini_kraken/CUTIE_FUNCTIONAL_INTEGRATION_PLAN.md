# 🚀 CUTIE FUNCTIONAL INTEGRATION FOR DRONET V3

**Status**: Fixing CUTIE data path disconnection  
**Goal**: Enable CUTIE as a fully functional DNN accelerator

---

## **ISSUE IDENTIFIED** 🔴

Current `kraken_soc_func.sv` instantiates CUTIE with **ONLY**:
- Clock and reset → `clk_i, rst_ni`
- Config bus (PWM writes) → `cfg_bus`
- Event outputs → `evt_o`
- Busy signal → `busy_o`

**MISSING (All data I/O disconnected)**:
- Weight memory write port
- Activation memory write port  
- Result readback path
- Configuration from MMIO registers

This is a **structural proof-of-concept only** - CUTIE is synthesized but cannot run inference.

---

## **SOLUTION: Three Integration Levels**

### **Level 1: Memory-Mapped CUTIE (Recommended for DroNet v3)**

**Configure CUTIE via CPU memory-mapped registers:**

```
Register Map:
0x0000 - START control
0x0004 - COMPUTE_DISABLE
0x0008 - CONFIG status
...
0x0100-0x013C - Weight write ports (96 banks)
0x0140-0x017C - Activation write ports (96 banks)
0x0180 - Readback control
0x0184 - Results (via DMA or polling)
```

**Design Flow:**
1. CPU core loads DroNet weights into L2 SRAM
2. CPU writes to CUTIE MMIO (through config sequencer)
3. CUTIE executes inference
4. CPU reads results from MMIO

---

## **LEVEL 2: CUTIE Data Port Exposure (Advanced)**

**Direct access to CUTIE memory interfaces:**

```
Expose:
- actmem_wport (96 input channels, write enable per bank)
- weightmem_wport (96 banks, parallel write)
- datapath outputs (96 result channels)
- Ready/Valid handshaking
```

**Design Flow:**
1. CPU DMAs weights directly to CUTIE weight memory
2. CPU DMAs activation data directly to CUTIE activation memory
3. Triggers computation
4. Reads results via DMA

---

## **LEVEL 3: Full CPU Cluster Integration (Minimum)**

**Make Cluster aware of CUTIE:**

```
Add to Cluster AXI:
- CUTIE as AXI slave
- Separate address space: 0x3000_0000 - 0x3FFF_FFFF
- Weight/activation DMA channels
- Result polling interface
```

---

## **IMMEDIATE FIX: Expose CUTIE Ports**

Update `kraken_soc_func.sv` to expose CUTIE data interfaces:

```systemverilog
module kraken_soc_func #(...) (
  ...
  // CUTIE Configuration (MMIO)
  output logic [31:0] cutie_wgt_data_o,      // Weight data output
  output logic [95:0] cutie_wgt_wr_o,        // Weight write per-bank
  
  output logic [31:0] cutie_act_data_o,      // Activation data output
  output logic [95:0] cutie_act_wr_o,        // Activation write per-bank
  
  input  logic [31:0] cutie_result_i,        // Result readback
  output logic        cutie_compute_o        // Start computation
);
```

This exposes CUTIE to external firmware/software control.

---

## **FILES TO MODIFY**

### **FILE 1**: `rtl/kraken_soc_func.sv`
- Expose CUTIE data I/O ports through top-level interface
- Remove PWM sequencer (replace with firmware-driven sequencer)
- Add register file decoder for MMIO writes

### **FILE 2**: `ips/cutie/rtl/cutie_hwpe_wrap.sv`
- Connect weight memory write port
- Connect activation memory write port
- All register writes now trigger actual accelerator operation

### **FILE 3**: `constraints/kraken_soc_func_synth.xdc`
- Remove false_path assertions on CUTIE (it's functional now!)
- Add timing constraints for CUTIE→CPU feedback paths

### **FILE 4**: Create `sw/dronet_v3_driver.c`
- Driver code for DroNet v3 to use CUTIE
- Weight loading
- Inference control
- Result readback

---

## **CRITICAL PARAMETER CHECK FOR DRONET V3**

DroNet v3 architecture (typical):
- **Input**: 80×124 RGB → split to Y/UV
- **Layers**: ~10-12 conv layers + pooling
- **Width**: 3-24 channels per layer
- **Kernel**: Mostly 3×3, some 5×5

**CUTIE Capability** (current config):
```
Parameter N_I = 96  ✅ (sufficient for DroNet input)
Parameter N_O = 96  ✅ (sufficient output channels)
Kernel K = 3        ✅ (matches DroNet 3×3 kernels)
IMAGEWIDTH = 64     ⚠️  (DroNet uses 80→40→20→10 pyramid)
IMAGEHEIGHT = 64    ⚠️  (DroNet uses 124→62→31→15 pyramid)
```

**Possible issue**: Image dimensions are hard-coded. Need to verify DroNet fits in 64×64 tiles, or create tiling strategy.

---

## **NEXT IMMEDIATE STEPS**

1. **✅ Add data port exposure to kraken_soc_func.sv**
2. **✅ Update constraints to remove false_path on CUTIE**
3. **⏳ Create DroNet v3 driver skeleton**
4. **⏳ Test with small inference (1 conv layer)**
5. **⏳ Verify image tiling for multi-layer inference**

---

## **TIMELINE**

- **Today**: Expose CUTIE data ports + fix constraints (30 min)
- **Tomorrow**: Create firmware driver (2 hours)
- **Day 3**: Single-layer test on board (1 hour)
- **Day 4-5**: Full DroNet v3 integration (4 hours)

---

**Status**: Ready to proceed with Level 1 + Level 2 hybrid integration.

# Mini-Kraken Status

This repository is currently best described as a working single-core
mini-Kraken bring-up platform with a real CUTIE MMIO-driven smoke flow.

## Current score

- Functional bring-up: 8/10
- Architectural faithfulness to original Kraken: 5/10
- FPGA readiness: 6/10
- Overall practical closeness to Kraken: 6/10

## What is working now

- Single-core CV32E40P cluster boots firmware through the local SoC shell.
- Local SRAM instruction/data path is active in functional simulation.
- CUTIE is configured by firmware through MMIO, not by a hidden demo sequencer.
- The DroNet-oriented smoke firmware completes successfully in behavioral sim.
- The verified passing DroNet smoke markers are:
  - `dronet_scratch0=YES`
  - `dronet_scratch1=YES`
  - `uart_D=YES`
  - `cutie_cfg_write=YES`
  - `cutie_start_write=YES`
  - `cutie_done_evt=YES`
  - `cutie_timeout_evt=NO`
  - `profile_checkpoint=PASS`
  - `FIRMWARE_BOOT_CHECK: PASS`

## What is intentionally simplified

- The design is still single-core.
- The active SoC shell is simplified compared with a fuller Kraken subsystem.
- The CUTIE integration is a compact MMIO wrapper, not the original richer subsystem.
- The current DroNet path is a smoke configuration, not a full exported multi-layer network run.

## What still needs work to reach roughly 8/10

- Close FPGA timing:
  - target `WNS >= 0`
  - target `TNS = 0`
- Strengthen CUTIE/SoC robustness further so the working smoke path is less fragile.
- Expand DroNet validation beyond smoke completion into stronger result checking.
- Improve documentation and separation of:
  - functional sim behavior
  - FPGA synthesis profile behavior
  - smoke-only assumptions

## Recommended commands

Firmware build and behavioral simulation from WSL:

```bash
cd /mnt/c/Users/kiran/fpga_project/mini_kraken/sw/dronet_v3
make clean all RISCV_PREFIX=riscv64-unknown-elf

cd /mnt/c/Users/kiran/fpga_project/mini_kraken
bash scripts/run_ff_rf_sim_wsl.sh /mnt/c/Users/kiran/fpga_project/mini_kraken/sw/dronet_v3/dronet_v3_driver.mem
```

FPGA synthesis/implementation from Vivado Tcl:

```tcl
cd C:/Users/kiran/fpga_project/mini_kraken/scripts/kraken_func_a7
source refresh_project.tcl
source run_synth_impl.tcl
```

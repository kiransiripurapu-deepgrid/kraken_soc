# RTL Analysis and Behavioral Simulation Verification
# This script checks for synthesis issues without running full P&R

puts "╔═══════════════════════════════════════════════════════════════╗"
puts "║         RTL VALIDATION & BEHAVIORAL SIM CHECK                ║"
puts "╚═══════════════════════════════════════════════════════════════╝"

set project_name "mini_kraken"
set rtl_path "./rtl"
set constraint_path "./constraints"

puts "\n[STEP 1] Opening project..."
open_project "${project_name}.xpr"

puts "\n[STEP 2] Checking RTL syntax and hierarchy..."
set_property top kraken_soc_func [get_filesets sources_1]
update_compile_order -fileset sources_1

# Check for elaboration issues
puts "  • Elaborating design..."
if {[catch {
    synth_design -rtl -name rtl_1 -part xc7a200tsbg484-1
} err]} {
    puts "  ⚠ Elaboration warning: $err"
    
    # Try to continue to report_hierarchy
    if {[catch {
        report_hierarchy
    } err2]} {
        puts "  ❌ Cannot continue: $err2"
    }
} else {
    puts "  ✅ Elaboration successful"
    
    # Report design statistics
    puts "\n[STEP 3] Design Statistics:"
    catch {report_design_analysis} output
    puts $output
    
    # Check utilization
    puts "\n[STEP 4] Resource Utilization:"
    catch {report_utilization -no_primitives} util_report
    # Show only summary line
    set lines [split $util_report "\n"]
    foreach line $lines {
        if {[string match "*| Slice LUTs*" $line] || [string match "*| Slice Registers*" $line] || [string match "*| BRAM*" $line] || [string match "*| DSP*" $line]} {
            puts $line
        }
    }
}

# Check constraints
puts "\n[STEP 5] Checking XDC Constraints..."
if {[file exists "${constraint_path}/kraken_soc_func_synth.xdc"]} {
    puts "  ✅ XDC file found"
    
    # Read and validate key constraints
    set xdc_content [read_file "${constraint_path}/kraken_soc_func_synth.xdc"]
    
    # Check for clock constraint
    if {[string match "*create_clock*" $xdc_content]} {
        puts "  ✅ Clock constraint present"
    } else {
        puts "  ❌ Clock constraint MISSING"
    }
    
    # Check for reset constraint
    if {[string match "*rst_ni*" $xdc_content] || [string match "*reset*" $xdc_content]} {
        puts "  ✅ Reset constraint present"
    } else {
        puts "  ❌ Reset constraint MISSING"
    }
    
    # Check output pins
    set output_count [regexp -all {set_property.*PACKAGE_PIN.*core_0_|mem_|cutie_} $xdc_content]
    if {$output_count > 50} {
        puts "  ✅ Output pins assigned ($output_count pins found)"
    } else {
        puts "  ⚠ Output pins might be incomplete ($output_count pins found)"
    }
} else {
    puts "  ❌ XDC file NOT found"
}

# Check testbench
puts "\n[STEP 6] Checking Simulation Testbench..."
if {[file exists "sim/kraken_soc_func_tb.sv"]} {
    puts "  ✅ Testbench found"
    
    set tb_content [read_file "sim/kraken_soc_func_tb.sv"]
    
    # Check key elements
    if {[string match "*always*clk*~clk*" $tb_content]} {
        puts "    • Clock generation: ✅"
    } else {
        puts "    • Clock generation: ⚠ May not be present"
    }
    
    if {[string match "*rst_ni*0*" $tb_content]} {
        puts "    • Reset assertion: ✅"
    } else {
        puts "    • Reset assertion: ⚠ May not be present"
    }
    
    if {[string match "*DUT*kraken_soc_func*" $tb_content] || [string match "*i_dut*kraken_soc_func*" $tb_content]} {
        puts "    • DUT instantiation: ✅"
    } else {
        puts "    • DUT instantiation: ⚠ May not be present"
    }
    
    if {[string match "*\$dumpfile*" $tb_content]} {
        puts "    • VCD generation: ✅"
    } else {
        puts "    • VCD generation: ⚠ May not be present"
    }
} else {
    puts "  ❌ Testbench NOT found"
}

# Check for simulation setup
puts "\n[STEP 7] Checking Simulation Configuration..."
if {[get_filesets sim_1] ne ""} {
    puts "  ✅ Simulation fileset exists"
    
    set sim_files [get_files -of_objects [get_filesets sim_1]]
    puts "    Simulation files: [llength $sim_files] files"
    
} else {
    puts "  ⚠ Simulation fileset not configured"
}

puts "\n[STEP 8] RTL Port Check..."
puts "  Module ports:"
set top_module [get_property top [get_filesets sources_1]]
catch {
    foreach port [get_ports] {
        set name [get_property NAME $port]
        set dir [get_property DIRECTION $port]
        set width [get_property REF_NAME $port]
        if {$dir eq "in"} {
            puts "    • IN  : $name"
        } else {
            puts "    • OUT : $name"
        }
    }
}

puts "\n╔═══════════════════════════════════════════════════════════════╗"
puts "║                   VALIDATION COMPLETE                         ║"
puts "╚═══════════════════════════════════════════════════════════════╝"

puts "\n✅ NEXT STEPS:"
puts "  1. Verify all outputs above are correctly assigned"
puts "  2. Check no CRITICAL warnings appear"
puts "  3. Run behavioral simulation: vivado -mode batch -source run_sim.tcl"
puts "  4. Review VCD waveforms in GTKWave or Vivado"
puts "  5. If simulation passes, synthesis can proceed"
puts "\n"

close_project

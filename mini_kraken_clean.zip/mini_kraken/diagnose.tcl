#!/usr/bin/env tclsh
# Minimal RTL/Simulation Diagnostic (No synthesis needed)

puts "\n╔═══════════════════════════════════════════════════════════════╗"
puts "║             BEHAVIORAL SIM & RTL DIAGNOSTICS                  ║"
puts "╚═══════════════════════════════════════════════════════════════╝\n"

# ==================== STEP 1: File Verification ====================
puts "📁 STEP 1: Checking Required Files..."

set required_files {
    "mini_kraken.xpr"
    "rtl/kraken_soc_func.sv"
    "sim/kraken_soc_func_tb.sv"
    "constraints/kraken_soc_func_synth.xdc"
}

set files_ok 1
foreach file $required_files {
    if {[file exists $file]} {
        set size [file size $file]
        puts "  ✅ $file ($size bytes)"
    } else {
        puts "  ❌ $file (NOT FOUND)"
        set files_ok 0
    }
}

if {!$files_ok} {
    puts "\n❌ ERROR: Missing required files. Cannot proceed."
    exit 1
}

puts "\n✅ All files present"

# ==================== STEP 2: Project Analysis ====================
puts "\n📋 STEP 2: Project Configuration..."

open_project mini_kraken.xpr

set top_module [get_property top [get_filesets sources_1]]
puts "  Top module: $top_module"

set device [get_property PART [current_project]]
puts "  Device: $device"

# ==================== STEP 3: RTL Port Check ====================
puts "\n🔌 STEP 3: RTL Port Verification..."

set_property top kraken_soc_func [get_filesets sources_1]
update_compile_order -fileset sources_1

set ports [get_ports -quiet]
if {[llength $ports] > 0} {
    puts "  Found [llength $ports] ports:"
    
    set in_count 0
    set out_count 0
    
    foreach port $ports {
        set name [get_property NAME $port]
        set dir [get_property DIRECTION $port]
        set bits [get_property REF_NAME $port]
        
        if {$dir eq "in"} {
            puts "    ✓ IN  : $name"
            incr in_count
        } else {
            puts "    ✓ OUT : $name"
            incr out_count
        }
    }
    puts "  Summary: $in_count inputs, $out_count outputs"
} else {
    puts "  ⚠ No ports found at top level"
}

# ==================== STEP 4: Constraint Check ====================
puts "\n⚙️  STEP 4: Constraint Validation..."

set xdc_file "constraints/kraken_soc_func_synth.xdc"
set xdc_content [read_file $xdc_file]

set checks {
    {"Clock constraint" "create_clock"}
    {"Clock package pin" "PACKAGE_PIN E3"}
    {"Reset package pin" "PACKAGE_PIN D9"}
    {"100MHz clock" "period 10"}
    {"Async reset path" "set_false_path.*rst_ni"}
    {"Address output pins" "core_0_addr_o"}
    {"Data output pins" "core_0_data_o"}
    {"Request output pin" "core_0_req_o"}
    {"Memory valid pin" "mem_valid_o"}
    {"Memory data pins" "mem_data_o"}
    {"CUTIE busy pin" "cutie_busy_o"}
    {"CUTIE event pins" "cutie_evt_o"}
}

foreach {check_name pattern} $checks {
    if {[regexp -nocase $pattern $xdc_content]} {
        puts "  ✅ $check_name"
    } else {
        puts "  ❌ $check_name MISSING"
    }
}

# ==================== STEP 5: RTL Source Check ====================
puts "\n📄 STEP 5: RTL Source Code Analysis..."

set rtl_content [read_file "rtl/kraken_soc_func.sv"]

# Check for required modules/signals
set rtl_checks {
    {"PULP cluster instantiation" "pulp_cluster"}
    {"CUTIE accelerator instantiation" "cutie_hwpe_wrap"}
    {"SRAM instantiation" "sram #"}
    {"Output assignment - addr" "assign core_0_addr_o"}
    {"Output assignment - data" "assign core_0_data_o"}
    {"Output assignment - req" "assign core_0_req_o"}
    {"Output assignment - mem_valid" "assign mem_valid_o"}
    {"Output assignment - cutie_busy" "assign cutie_busy_o"}
    {"Output assignment - cutie_evt" "assign cutie_evt_o"}
    {"Reset synchronizer" "always_ff.*rst_ni"}
}

foreach {check rtl_pattern} $rtl_checks {
    if {[regexp -nocase $rtl_pattern $rtl_content]} {
        puts "  ✅ $check"
    } else {
        puts "  ❌ $check MISSING"
    }
}

# ==================== STEP 6: Testbench Check ====================
puts "\n🧪 STEP 6: Testbench Validation..."

set tb_content [read_file "sim/kraken_soc_func_tb.sv"]

set tb_checks {
    {"Module declaration" "module kraken_soc_func_tb"}
    {"DUT instantiation" "kraken_soc_func.*DUT"}
    {"Clock generation" "always.*#.*CLK_PERIOD"}
    {"Reset logic" "rst_ni.*1'b0"}
    {"Clock monitoring" "@(posedge clk"}
    {"VCD dump" "\\$dumpfile"}
    {"Simulation end" "\\$finish"}
}

foreach {check tb_pattern} $tb_checks {
    if {[regexp -nocase $tb_pattern $tb_content]} {
        puts "  ✅ $check"
    } else {
        puts "  ❌ $check MISSING"
    }
}

# ==================== STEP 7: Simulation Fileset ====================
puts "\n🎬 STEP 7: Simulation Configuration..."

# Create sim_1 if it doesn't exist
if {[get_filesets sim_1] eq ""} {
    puts "  Creating simulation fileset..."
    create_fileset -simset sim_1
}

puts "  ✅ Simulation fileset ready"

# Check if testbench is added
set sim_files [get_files -of_objects [get_filesets sim_1]]
if {[llength $sim_files] > 0} {
    puts "  ✅ Simulation files present ([llength $sim_files] files)"
} else {
    puts "  ⚠️  No simulation files yet"
}

# ==================== FINAL REPORT ====================
puts "\n╔═══════════════════════════════════════════════════════════════╗"
puts "║                 DIAGNOSTICS COMPLETE                           ║"
puts "╚═══════════════════════════════════════════════════════════════╝"

puts "\n✅ SUMMARY:"
puts "  • RTL: kraken_soc_func with PULP + CUTIE + SRAM"
puts "  • I/O: 9 ports (clk, rst, 7 outputs)"
puts "  • Constraints: pins for Arty A7-200T (SBG484)"
puts "  • Testbench: kraken_soc_func_tb ready"
puts "  • Device: xc7a200tsbg484-1"

puts "\n📝 NEXT STEPS:"
puts "  1. Run behavioral simulation:"
puts "     vivado -mode batch -source run_sim.tcl"
puts "  2. Review VCD waveforms for signal activity"
puts "  3. Check for any ERROR/CRITICAL warnings"
puts "  4. Once simulation passes, synthesis can proceed"

close_project
puts "\n"

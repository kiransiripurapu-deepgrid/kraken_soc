`timescale 1ns/1ps

// Functional Kraken-style SoC for Arty A7-100T.
// Keeps the original 1-core cluster + local SRAM structure from kraken_soc,
// and adds a firmware-controlled CUTIE config window rather than a hidden
// synthetic accelerator sequencer.

module kraken_soc_func import axi_pkg::*; #(
  parameter int unsigned AXI_ADDR_WIDTH = 32,
  parameter int unsigned AXI_DATA_WIDTH = 64,
  parameter int unsigned AXI_ID_WIDTH   = 4,
  parameter bit          STRICT_SINGLE_OUTSTANDING = 1'b0
) (
  input  logic        clk_i,
  input  logic        rst_ni,
  input  logic        test_en_i,
  output logic [31:0] core_0_addr_o,
  output logic [31:0] core_0_data_o,
  output logic        core_0_req_o,
  output logic        mem_valid_o,
  output logic [31:0] mem_data_o,
  output logic        cutie_busy_o,
  output logic [1:0]  cutie_evt_o
);

  logic rst_sync_ff_q;
  logic rst_n_q;

  logic [0:0]       core_instr_req;
  logic [0:0]       core_instr_gnt;
  logic [0:0][31:0] core_instr_addr;
  logic [0:0]       core_instr_rvalid;
  logic [0:0][31:0] core_instr_rdata;
  logic             instr_req_fire;
  logic             instr_rsp_pop;
  logic             instr_rsp_can_accept;
  logic [1:0]       instr_rsp_count_q;
  logic [31:0]      instr_rsp_q0;
  logic [31:0]      instr_rsp_q1;
  logic             instr_rsp_pending_q;
  logic [31:0]      instr_rsp_data_q;
  logic             instr_rvalid_q;
  logic [31:0]      instr_rdata_q;
  logic [0:0]       core_data_req;
  logic [0:0]       core_data_gnt;
  logic [0:0]       core_data_we;
  logic [0:0][3:0]  core_data_be;
  logic [0:0][31:0] core_data_addr;
  logic [0:0][31:0] core_data_wdata;
  logic [0:0]       core_data_rvalid;
  logic [0:0][31:0] core_data_rdata;

  logic [15:0] mem_addr;
  logic [31:0] mem_rdata;
  logic        instr_is_l2;
  logic [31:0] instr_resp_new;
  logic [15:0] data_mem_addr;
  logic [31:0] data_mem_rdata;
  logic        data_is_local;
  logic        data_is_mmio;
  logic        data_is_cutie_cfg;
  logic        data_is_sne_cfg;
  logic [5:0]  mmio_word_addr;
  logic        data_req_fire;
  logic [31:0] data_resp_new;
  logic        data_rsp_push_fire;
  logic [31:0] data_rsp_push_data;
  logic        data_rsp_pop;
  logic        data_rsp_can_accept;
  logic [1:0]  data_rsp_count_q;
  logic [31:0] data_rsp_q0;
  logic [31:0] data_rsp_q1;
  logic        data_rsp_pending_q;
  logic [31:0] data_rsp_data_q;
  logic        data_rvalid_q;
  logic [31:0] data_rdata_q;
  logic [31:0] mmio_rdata;
  logic [31:0] mmio_scratch0_q;
  logic [31:0] mmio_scratch1_q;
  logic [31:0] mmio_gpio_q;
  logic [31:0] uart_tx_reg_q;
  logic [31:0] uart_status_q;
  logic [31:0] bad_access_q;
  logic [31:0] cutie_status_q;
  logic [31:0] cutie_readback_q;
  logic [31:0] cutie_status_live;
  logic        cutie_done_seen_q;
  logic        cutie_timeout_seen_q;
  logic [31:0] cycle_counter_q;
  logic [31:0] cutie_done_count_q;
  logic [31:0] cutie_timeout_count_q;
  logic        cutie_cfg_req_cpu;
  logic        cutie_cfg_wen_cpu;
  logic [31:0] cutie_cfg_addr_cpu;
  logic [31:0] cutie_cfg_wdata_cpu;
  logic [31:0] cutie_cfg_addr_q;
  localparam logic [31:0] MMIO_BASE_ADDR      = 32'h1A10_0000;
  localparam logic [31:0] CUTIE_CFG_BASE_ADDR = 32'h1A11_0000;
  localparam logic [31:0] SNE_CFG_BASE_ADDR   = 32'h1A12_0000;
  localparam logic [31:0] LOCAL_MEM_LAST_ADDR = 32'h0003_FFFF;
  localparam logic [31:0] BAD_ACCESS_RDATA = 32'hDEAD_BEEF;
  localparam logic [5:0] MMIO_SCRATCH0_OFFSET    = 6'h00;
  localparam logic [5:0] MMIO_SCRATCH1_OFFSET    = 6'h01;
  localparam logic [5:0] MMIO_GPIO_OFFSET        = 6'h02;
  localparam logic [5:0] MMIO_UART_TX_OFFSET     = 6'h03;
  localparam logic [5:0] MMIO_UART_STATUS_OFFSET = 6'h04;
  localparam logic [5:0] MMIO_BAD_ACCESS_OFFSET  = 6'h05;
  localparam logic [5:0] MMIO_CYCLE_COUNT_OFFSET = 6'h06;
  localparam logic [5:0] MMIO_CUTIE_DONE_COUNT_OFFSET = 6'h07;
  localparam logic [5:0] MMIO_CUTIE_TIMEOUT_COUNT_OFFSET = 6'h08;
  localparam logic [5:0] MMIO_CUTIE_STATUS_OFFSET = 6'h0C;
  localparam logic [5:0] MMIO_CUTIE_READBACK_OFFSET = 6'h0D;

  // Keep a short local reset release delay so the simplified always-ready
  // instruction/data responses do not hit the core on the very first cycle
  // out of reset. This was part of the last known-good functional behavior.
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      rst_sync_ff_q <= 1'b0;
      rst_n_q       <= 1'b0;
    end else begin
      rst_sync_ff_q <= 1'b1;
      rst_n_q       <= rst_sync_ff_q;
    end
  end

  pulp_cluster #(
    .NR_CORES        ( 1              ),
    .AXI_ADDR_WIDTH  ( AXI_ADDR_WIDTH ),
    .AXI_DATA_WIDTH  ( AXI_DATA_WIDTH ),
    .AXI_ID_WIDTH    ( AXI_ID_WIDTH   ),
    .TCDM_ADDR_WIDTH ( 13             ),
    .TCDM_DATA_WIDTH ( 64             )
  ) i_pulp_cluster (
    .clk_i               ( clk_i             ),
    .rst_ni              ( rst_n_q           ),
    .test_en_i           ( test_en_i         ),
    .core_instr_req_o    ( core_instr_req    ),
    .core_instr_gnt_i    ( core_instr_gnt    ),
    .core_instr_addr_o   ( core_instr_addr   ),
    .core_instr_rvalid_i ( core_instr_rvalid ),
    .core_instr_rdata_i  ( core_instr_rdata  ),
    .core_data_req_o     ( core_data_req     ),
    .core_data_gnt_i     ( core_data_gnt     ),
    .core_data_we_o      ( core_data_we      ),
    .core_data_be_o      ( core_data_be      ),
    .core_data_addr_o    ( core_data_addr    ),
    .core_data_wdata_o   ( core_data_wdata   ),
    .core_data_rvalid_i  ( core_data_rvalid  ),
    .core_data_rdata_i   ( core_data_rdata   )
  );

  assign mem_addr             = core_instr_addr[0][17:2];
  assign instr_is_l2          = (core_instr_addr[0] <= LOCAL_MEM_LAST_ADDR);
  assign data_mem_addr        = core_data_addr[0][17:2];
  assign data_is_local        = ~data_is_mmio & ~data_is_cutie_cfg & (core_data_addr[0] <= LOCAL_MEM_LAST_ADDR);
  assign instr_rsp_pop        = rst_n_q & (instr_rsp_count_q != 2'd0) & ~STRICT_SINGLE_OUTSTANDING;
  assign instr_rsp_can_accept = (instr_rsp_count_q != 2'd2) || instr_rsp_pop;
  assign core_instr_gnt[0]    = core_instr_req[0] &
                                (STRICT_SINGLE_OUTSTANDING ? ~instr_rsp_pending_q : instr_rsp_can_accept);
  assign instr_req_fire       = core_instr_req[0] & core_instr_gnt[0];
  assign core_instr_rvalid[0] = STRICT_SINGLE_OUTSTANDING ? instr_rsp_pending_q : instr_rvalid_q;
  assign core_instr_rdata[0]  = STRICT_SINGLE_OUTSTANDING ? instr_rsp_data_q : instr_rdata_q;
  assign data_is_mmio         = (core_data_addr[0][31:12] == MMIO_BASE_ADDR[31:12]);
  assign data_is_cutie_cfg    = (core_data_addr[0][31:12] == CUTIE_CFG_BASE_ADDR[31:12]);
  assign data_is_sne_cfg      = (core_data_addr[0][31:12] == SNE_CFG_BASE_ADDR[31:12]);
  assign mmio_word_addr       = core_data_addr[0][7:2];
  assign data_rsp_pop         = rst_n_q & (data_rsp_count_q != 2'd0) & ~STRICT_SINGLE_OUTSTANDING;
  assign data_rsp_can_accept  = (data_rsp_count_q != 2'd2) || data_rsp_pop;
  assign core_data_gnt[0]     = core_data_req[0] &
                                (data_is_sne_cfg ? sne_cfg_bus.gnt :
                                 (STRICT_SINGLE_OUTSTANDING ? ~data_rsp_pending_q : data_rsp_can_accept));
  assign data_req_fire        = core_data_req[0] & core_data_gnt[0];
  assign core_data_rvalid[0]  = STRICT_SINGLE_OUTSTANDING ? data_rsp_pending_q : data_rvalid_q;
  assign core_data_rdata[0]   = STRICT_SINGLE_OUTSTANDING ? data_rsp_data_q : data_rdata_q;

  sram #(
    .DATA_WIDTH ( 32    ),
    .NUM_WORDS  ( 65536 )
  ) i_l2_mem (
    .clk_i   ( clk_i             ),
    .req_i   ( instr_req_fire & instr_is_l2 ),
    .we_i    ( 1'b0              ),
    .addr_i  ( mem_addr          ),
    .wdata_i ( 32'h0             ),
    .be_i    ( 32'hFFFF_FFFF     ),
    .rdata_o ( mem_rdata         )
  );

  assign instr_resp_new = instr_is_l2 ? mem_rdata : BAD_ACCESS_RDATA;

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      instr_rsp_count_q <= 2'd0;
      instr_rsp_q0      <= 32'd0;
      instr_rsp_q1      <= 32'd0;
      instr_rsp_pending_q <= 1'b0;
      instr_rsp_data_q    <= 32'd0;
      instr_rvalid_q    <= 1'b0;
      instr_rdata_q     <= 32'd0;
    end else begin
      if (STRICT_SINGLE_OUTSTANDING) begin
        instr_rsp_pending_q <= instr_req_fire;
        if (instr_req_fire)
          instr_rsp_data_q <= instr_resp_new;

        instr_rsp_count_q <= 2'd0;
        instr_rsp_q0      <= 32'd0;
        instr_rsp_q1      <= 32'd0;
        instr_rvalid_q    <= 1'b0;
        instr_rdata_q     <= 32'd0;
      end else begin
        instr_rsp_pending_q <= 1'b0;
        instr_rvalid_q <= instr_rsp_pop;
        if (instr_rsp_pop) begin
          instr_rdata_q <= instr_rsp_q0;
        end

        unique case ({instr_req_fire, instr_rsp_pop})
          2'b00: begin
            // no push/pop
          end
          2'b01: begin
            // pop only
            if (instr_rsp_count_q == 2'd2)
              instr_rsp_q0 <= instr_rsp_q1;
            instr_rsp_count_q <= instr_rsp_count_q - 2'd1;
          end
          2'b10: begin
            // push only
            if (instr_rsp_count_q == 2'd0)
              instr_rsp_q0 <= instr_resp_new;
            else if (instr_rsp_count_q == 2'd1)
              instr_rsp_q1 <= instr_resp_new;
            instr_rsp_count_q <= (instr_rsp_count_q == 2'd2) ? 2'd2 : (instr_rsp_count_q + 2'd1);
          end
          2'b11: begin
            // push and pop in same cycle (count stays constant)
            if (instr_rsp_count_q == 2'd1) begin
              instr_rsp_q0 <= instr_resp_new;
            end else if (instr_rsp_count_q == 2'd2) begin
              instr_rsp_q0 <= instr_rsp_q1;
              instr_rsp_q1 <= instr_resp_new;
            end
          end
        endcase
      end
    end
  end

  sram #(
    .DATA_WIDTH ( 32    ),
    .NUM_WORDS  ( 65536 )
  ) i_data_mem (
    .clk_i   ( clk_i              ),
    .req_i   ( data_req_fire & data_is_local ),
    .we_i    ( core_data_we[0]    ),
    .addr_i  ( data_mem_addr      ),
    .wdata_i ( core_data_wdata[0] ),
    .be_i    ( {{8{core_data_be[0][3]}},
                {8{core_data_be[0][2]}},
                {8{core_data_be[0][1]}},
                {8{core_data_be[0][0]}}} ),
    .rdata_o ( data_mem_rdata     )
  );

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      mmio_scratch0_q <= 32'd0;
      mmio_scratch1_q <= 32'd0;
      mmio_gpio_q     <= 32'd0;
      uart_tx_reg_q   <= 32'd0;
      uart_status_q   <= 32'h0000_0001;
      bad_access_q    <= 32'd0;
      cycle_counter_q <= 32'd0;
      cutie_done_count_q <= 32'd0;
      cutie_timeout_count_q <= 32'd0;
      cutie_done_seen_q <= 1'b0;
      cutie_timeout_seen_q <= 1'b0;
`ifndef SYNTHESIS
    end else if (data_req_fire && core_data_we[0] && (data_is_mmio === 1'b1) &&
                 !$isunknown(core_data_addr[0][7:2]) && !$isunknown(core_data_wdata[0])) begin
`else
    end else if (data_req_fire && core_data_we[0] && data_is_mmio) begin
`endif
      cycle_counter_q <= cycle_counter_q + 32'd1;
      if (cutie_evt_o[0]) begin
        cutie_done_count_q <= cutie_done_count_q + 32'd1;
        cutie_done_seen_q <= 1'b1;
      end
      if (cutie_evt_o[1]) begin
        cutie_timeout_count_q <= cutie_timeout_count_q + 32'd1;
        cutie_timeout_seen_q <= 1'b1;
      end
      unique case (mmio_word_addr)
        MMIO_SCRATCH0_OFFSET:    mmio_scratch0_q <= core_data_wdata[0];
        MMIO_SCRATCH1_OFFSET:    mmio_scratch1_q <= core_data_wdata[0];
        MMIO_GPIO_OFFSET:        mmio_gpio_q     <= core_data_wdata[0];
        MMIO_UART_TX_OFFSET:     uart_tx_reg_q   <= core_data_wdata[0];
        MMIO_BAD_ACCESS_OFFSET:  bad_access_q    <= core_data_wdata[0];
        MMIO_CYCLE_COUNT_OFFSET: cycle_counter_q <= core_data_wdata[0];
        MMIO_CUTIE_DONE_COUNT_OFFSET: cutie_done_count_q <= core_data_wdata[0];
        MMIO_CUTIE_TIMEOUT_COUNT_OFFSET: cutie_timeout_count_q <= core_data_wdata[0];
        default: ;
      endcase
    end else if (data_req_fire && ~data_is_local && ~data_is_mmio && ~data_is_cutie_cfg && ~data_is_sne_cfg) begin
      cycle_counter_q <= cycle_counter_q + 32'd1;
      if (cutie_evt_o[0]) begin
        cutie_done_count_q <= cutie_done_count_q + 32'd1;
        cutie_done_seen_q <= 1'b1;
      end
      if (cutie_evt_o[1]) begin
        cutie_timeout_count_q <= cutie_timeout_count_q + 32'd1;
        cutie_timeout_seen_q <= 1'b1;
      end
      bad_access_q <= bad_access_q + 32'd1;
    end else begin
      cycle_counter_q <= cycle_counter_q + 32'd1;
      if (cutie_evt_o[0]) begin
        cutie_done_count_q <= cutie_done_count_q + 32'd1;
        cutie_done_seen_q <= 1'b1;
      end
      if (cutie_evt_o[1]) begin
        cutie_timeout_count_q <= cutie_timeout_count_q + 32'd1;
        cutie_timeout_seen_q <= 1'b1;
      end
      if (data_req_fire && core_data_we[0] && (data_is_cutie_cfg === 1'b1) &&
          (core_data_addr[0][11:0] == 12'h000) && core_data_wdata[0][0]) begin
        cutie_done_seen_q <= 1'b0;
        cutie_timeout_seen_q <= 1'b0;
      end
    end
  end

  always_comb begin
    if (data_is_cutie_cfg) begin
      data_resp_new = core_data_we[0] ? 32'd0 : cutie_cfg_bus.r_rdata;
    end else if (data_is_sne_cfg) begin
      data_resp_new = sne_cfg_bus.r_rdata;
    end else if (data_is_mmio) begin
      data_resp_new = core_data_we[0] ? 32'd0 : mmio_rdata;
    end else if (data_is_local) begin
      data_resp_new = data_mem_rdata;
    end else begin
      data_resp_new = core_data_we[0] ? 32'd0 : BAD_ACCESS_RDATA;
    end
  end

  assign data_rsp_push_fire = (data_req_fire && (!data_is_sne_cfg || core_data_we[0])) ||
                              sne_cfg_bus.r_valid;
  assign data_rsp_push_data = sne_cfg_bus.r_valid ? sne_cfg_bus.r_rdata : data_resp_new;

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      data_rsp_count_q <= 2'd0;
      data_rsp_q0      <= 32'd0;
      data_rsp_q1      <= 32'd0;
      data_rsp_pending_q <= 1'b0;
      data_rsp_data_q    <= 32'd0;
      data_rvalid_q    <= 1'b0;
      data_rdata_q     <= 32'd0;
    end else begin
      if (STRICT_SINGLE_OUTSTANDING) begin
        data_rsp_pending_q <= data_rsp_push_fire;
        if (data_rsp_push_fire)
          data_rsp_data_q <= data_rsp_push_data;

        data_rsp_count_q <= 2'd0;
        data_rsp_q0      <= 32'd0;
        data_rsp_q1      <= 32'd0;
        data_rvalid_q    <= 1'b0;
        data_rdata_q     <= 32'd0;
      end else begin
        data_rsp_pending_q <= 1'b0;
        data_rvalid_q <= data_rsp_pop;
        if (data_rsp_pop) begin
          data_rdata_q <= data_rsp_q0;
        end

        unique case ({data_rsp_push_fire, data_rsp_pop})
          2'b00: begin
            // no push/pop
          end
          2'b01: begin
            // pop only
            if (data_rsp_count_q == 2'd2)
              data_rsp_q0 <= data_rsp_q1;
            data_rsp_count_q <= data_rsp_count_q - 2'd1;
          end
          2'b10: begin
            // push only
            if (data_rsp_count_q == 2'd0)
              data_rsp_q0 <= data_rsp_push_data;
            else if (data_rsp_count_q == 2'd1)
              data_rsp_q1 <= data_rsp_push_data;
            data_rsp_count_q <= (data_rsp_count_q == 2'd2) ? 2'd2 : (data_rsp_count_q + 2'd1);
          end
          2'b11: begin
            // push and pop in same cycle
            if (data_rsp_count_q == 2'd1) begin
              data_rsp_q0 <= data_rsp_push_data;
            end else if (data_rsp_count_q == 2'd2) begin
              data_rsp_q0 <= data_rsp_q1;
              data_rsp_q1 <= data_rsp_push_data;
            end
          end
        endcase
      end
    end
  end

  assign cutie_cfg_req_cpu   = data_req_fire && (data_is_cutie_cfg === 1'b1);
  assign cutie_cfg_wen_cpu   = ~core_data_we[0];
  assign cutie_cfg_addr_cpu  = {20'd0, core_data_addr[0][11:0]};
  assign cutie_cfg_wdata_cpu = core_data_wdata[0];

  always_comb begin
    unique case (mmio_word_addr)
      MMIO_SCRATCH0_OFFSET:      mmio_rdata = mmio_scratch0_q;
      MMIO_SCRATCH1_OFFSET:      mmio_rdata = mmio_scratch1_q;
      MMIO_GPIO_OFFSET:          mmio_rdata = mmio_gpio_q;
      MMIO_UART_TX_OFFSET:       mmio_rdata = uart_tx_reg_q;
      MMIO_UART_STATUS_OFFSET:   mmio_rdata = uart_status_q;
      MMIO_BAD_ACCESS_OFFSET:    mmio_rdata = bad_access_q;
      MMIO_CYCLE_COUNT_OFFSET:   mmio_rdata = cycle_counter_q;
      MMIO_CUTIE_DONE_COUNT_OFFSET: mmio_rdata = cutie_done_count_q;
      MMIO_CUTIE_TIMEOUT_COUNT_OFFSET: mmio_rdata = cutie_timeout_count_q;
      MMIO_CUTIE_STATUS_OFFSET:  mmio_rdata = cutie_status_live;
      MMIO_CUTIE_READBACK_OFFSET:mmio_rdata = cutie_readback_q;
      default: mmio_rdata = 32'hDEAD_B33F;
    endcase
  end

  XBAR_PERIPH_BUS cutie_cfg_bus();

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      cutie_status_q   <= 32'd0;
      cutie_readback_q <= 32'd0;
      cutie_cfg_addr_q <= 32'd0;
    end else begin
      if (cutie_cfg_req_cpu && cutie_cfg_wen_cpu) begin
        cutie_cfg_addr_q <= cutie_cfg_addr_cpu;
      end

      if (cutie_cfg_bus.r_valid) begin
        if (cutie_cfg_addr_q == 32'h0000_0000) begin
          cutie_status_q[31:3] <= cutie_cfg_bus.r_rdata[31:3];
        end else begin
          cutie_readback_q <= cutie_cfg_bus.r_rdata;
        end
      end
    end
  end

  always_comb begin
    cutie_status_live = 32'd0;
    cutie_status_live[0]   = cutie_busy_o;
    cutie_status_live[1]   = cutie_done_seen_q | cutie_evt_o[0];
    cutie_status_live[2]   = cutie_timeout_seen_q | cutie_evt_o[1];
    cutie_status_live[31:3]= cutie_status_q[31:3];
  end

  assign cutie_cfg_bus.req   = cutie_cfg_req_cpu;
  assign cutie_cfg_bus.add   = cutie_cfg_addr_cpu;
  assign cutie_cfg_bus.wen   = cutie_cfg_wen_cpu;
  assign cutie_cfg_bus.wdata = cutie_cfg_wdata_cpu;
  assign cutie_cfg_bus.be    = 4'hF;
  assign cutie_cfg_bus.id    = '0;

  cutie_hwpe_wrap i_cutie (
    .clk_i   ( clk_i         ),
    .rst_ni  ( rst_n_q       ),
    .cfg_bus ( cutie_cfg_bus ),
    .evt_o   ( cutie_evt_o   ),
    .busy_o  ( cutie_busy_o  )
  );

  // ── SNE integration ────────────────────────────────────────────────────────
  // Separate track from CUTIE; uses an independent 4 KB window at 0x1A12_0000.
  XBAR_PERIPH_BUS sne_cfg_bus();

  logic        sne_busy;
  logic [1:0]  sne_evt;

  assign sne_cfg_bus.req   = core_data_req[0] && (data_is_sne_cfg === 1'b1);
  assign sne_cfg_bus.add   = {20'd0, core_data_addr[0][11:0]};
  assign sne_cfg_bus.wen   = ~core_data_we[0];
  assign sne_cfg_bus.wdata = core_data_wdata[0];
  assign sne_cfg_bus.be    = 4'hF;
  assign sne_cfg_bus.id    = '0;

  sne_wrap i_sne (
    .clk_i   ( clk_i       ),
    .rst_ni  ( rst_n_q     ),
    .cfg_bus ( sne_cfg_bus ),
    .evt_o   ( sne_evt     ),
    .busy_o  ( sne_busy    )
  );

  assign core_0_addr_o = core_instr_addr[0];
  assign core_0_data_o = core_instr_rdata[0];
  assign core_0_req_o  = core_instr_req[0];
  assign mem_valid_o   = core_instr_rvalid[0] | core_data_rvalid[0];
  assign mem_data_o    = core_data_rvalid[0] ? core_data_rdata[0] : core_instr_rdata[0];

endmodule
